# giphy-block
Workshop to create a Gutenberg block.
